## graphql schema
go run artisan.go gql api
go run artisan.go gql admin

## database sql
go run artisan.go migration [create_table_name] [db_name]

go run artisan.go migration create_products solomo

## database migrate
go run artisan.go migrate -e [db_name]

UP
go run artisan.go migrate -e solomo

DOWN
go run artisan.go migrate down -e solomo

## project layout
https://github.com/golang-standards/project-layout

email
動態參數


error if

golang no optional


JWT
https://gist.github.com/nanoninja/50e56791d13d340068ccf4f6c810dbf7

table

gql 
paginate

audits
    id
    user_table
    user_id

uuids

jobs

password_resets
    email
    token
    created_at

oauth_access_tokens
    revoked
    expires_at

oauth_refresh_tokens
    access_tokens_id
    revoked
    expires_at