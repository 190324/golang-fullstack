package middlewares

func Authenticate() {
	
}