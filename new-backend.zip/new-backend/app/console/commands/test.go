package commands

import "log"

func Test()  {
	log.Printf("echo test")
}